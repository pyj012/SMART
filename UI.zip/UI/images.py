import sys, os
class image():
    background = os.path.join(sys.path[0],"image/background.png")
    connected = os.path.join(sys.path[0],"image/connected")
    disconnected = os.path.join(sys.path[0],"image/disconnected")