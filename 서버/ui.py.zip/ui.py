import sys, time
from PyQt5.QtCore import QThread, Qt
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton
from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QFont
class refreshSignal(QThread):
    signal1 = pyqtSignal()
    def __init__(self):
        super().__init__()      
   
    def run(self):
        while True:
            self.signal1.emit()
            time.sleep(0.001)

class MainApplication(QWidget):

    def __init__(self):
        super().__init__()
        self.function()
        self.creatUI()

    def creatUI(self):
        self.setWindowTitle('SMART')
        self.move(0, 0)
        self.resize(1280, 720)
        self.setStyleSheet(
            """
                background : White;
            """
        )
        self.label = QLabel(self)
        self.label.setText("SMART")
        self.label.setGeometry(1280/2-150, 720/2-150, 300, 300)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setFont(QFont("Arial",30))
        self.label.setStyleSheet(
            """
                color : Black;
            """
        )
        self.show()
     
    def function(self):
        self.Thread1 = refreshSignal()
        self.Thread1.signal1.connect(self.refresh) #사용자 정의 시그널1 슬롯 Connect
        self.Thread1.start()

    def refresh(self):
        print("HELLO")

if __name__ == '__main__':
   app = QApplication(sys.argv)
   ex = MainApplication()
   sys.exit(app.exec_())