import socket, time, os
import threading 
import sys
import random
import json
import struct
import pickle
# import cv2
# import mediapipe as mp
import numpy as np
from collections import deque
import heapq
# from LowPassFilterTest import LowPassFilter
from protocol import *

data = {1:0, 2:0, 3:0, 4:0, 5:0, 6:0}
angle0 = {'cmd_type':0xC0,'1': 0,'2': 0,'3': 0,'4': 0,'5': 0,'6': 0}
angle150 = {'cmd_type':0xC0,'1': 150,'2': 150,'3': 150,'4': 150,'5': 150,'6': 150}
angle1 = {'cmd_type':0xC0,'0':0,'1':10,'2':20,'3':30,'4':40,'5':50,'6':60,'7':70,'8':80,'9':90,'10':100,'11':110,'12':120,'13':130,'14':140,'15':150}
angle2 = {'cmd_type':0xC0,'7':70,'8':80,'9':90,'10':100,'11':110,'12':120,'13':130,'14':140,'15':150}
angle3 = {'cmd_type':0xA0,'0':0,'1':10,'2':20,'3':30,'4':40,'5':50,'6':60,'7':70}
angle4 = {'cmd_type':0xA0,'0':0,'2':20,'4':40,'6':60,'8':80,'10':100,'12':120,'14':140}

#테스트용 각도 순환
keyvalue=['1', '2', '3', '4', '5', '6']
angle= 0

prevSendTime = time.time()

lock = threading.Lock()
SERVER_HOST = "192.168.20.3"
SERVER_PORT = 5051

# print(mp.__version__)

# mp_drawing = mp.solutions.drawing_utils
# mp_holistic = mp.solutions.holistic

class SocketServer():
    def __init__(self):
        # 서버 구동에 필요한 정보 세팅
        self._host = SERVER_HOST
        self._port = SERVER_PORT
        self._data = data
        self._angle = angle
        self._prestate = data
        self.ai_result={}
        self._sendtime = ""
        self.client_socket =None
        self.lpf = []
        self.SMART = smartprotocol()
        self.client_socket =socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client_socket.connect((SERVER_HOST, SERVER_PORT))
        
        serverthread = threading.Thread(target= self._handle_client, args=(self.client_socket,))
        serverthread.daemon = True
        serverthread.start()

        while(1):
            # self.aitest()
            pass

    # def aitest(self):
    #     cap = cv2.VideoCapture(0)
    #     with mp_holistic.Holistic(model_complexity = 1,min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
            
    #         while cap.isOpened():
    #             ret, frame = cap.read()
    #             # Recolor Feed
    #             image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    #             # Make Detections
    #             results = holistic.process(image)

    #             # Recolor image back to BGR for rendering
    #             image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
                        
    #             # 이미지에서 BGR을 RGB로 변환합니다.
    #             image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    #             # Holistic 모델로 랜드마크 추정을 수행합니다.
    #             results = holistic.process(image_rgb)

    #             # 결과 이미지를 복사하여 출력 이미지를 준비합니다.
    #             output_image = image.copy()

    #             # Pose 랜드마크를 그리고 싶은 인덱스
    #             pose_landmark_indices = [11, 12, 13, 14, 15, 16]
    #             pose_connections = [(11, 13), (13, 15), (12, 14), (14, 16)]

    #             if results.pose_landmarks is not None:
    #                 joint = np.zeros((33,4))
    #                 for j, lm in enumerate(results.pose_landmarks.landmark):
    #                         joint[j] = [lm.x, lm.y, lm.z, lm.visibility]

    #                 #z축을 사용하여 각도를 뽑아내는 것으로 추정
    #                 v1 = joint[[11,11,13,13,15,15],:] # Parent joint
    #                 v2 = joint[[23,13,11,15,13,19],:] # Child joint
    #                 v = v2 - v1

    #                 #3,4번 제거
    #                 v[:, 2] = 0
    #                 v = np.delete(v, 3, axis=1)
    #                 #print(v)

    #                 v = v / np.linalg.norm(v, axis=1)[:, np.newaxis]

    #                 angle = np.arccos(np.einsum('nt,nt->n',
    #                                             v[[0,1,2,3,4],:], 
    #                                             v[[1,2,3,4,5],:])) # [15,]
                    
    #                 angle = np.degrees(angle) # Convert radian to degree"""

    #                 global prevSendTime
    #                 if time.time()-prevSendTime>=0.01:
    #                     self._sendtime = time.time()

    #                     sendValue = dict()
                        
    #                     self.lpf[1] = LowPassFilter(3.,0.1)
    #                     self.lpf[3] = LowPassFilter(3.,0.1)
    #                     self.lpf[4] = LowPassFilter(3.,0.1)
    #                     sendValue[1] = self.lpf[1].filter(int(angle[0]))
    #                     sendValue[3] = self.lpf[3].filter(180 - int(angle[2]))
    #                     sendValue[4] = self.lpf[4].filter(180 - int(angle[4]))

    #                     self._data = sendValue
    #                     prevSendTime = time.time()
                    
    #                 cv2.putText(output_image, text=str(round(sendValue[1],1)), org=(int(results.pose_landmarks.landmark[11].x * image.shape[1]), int(results.pose_landmarks.landmark[11].y * image.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(0, 0, 255), thickness=2)
    #                 cv2.putText(output_image, text=str(round(sendValue[3],1)), org=(int(results.pose_landmarks.landmark[13].x * image.shape[1]), int(results.pose_landmarks.landmark[13].y * image.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(0, 0, 255), thickness=2)
    #                 cv2.putText(output_image, text=str(round(sendValue[4],1)), org=(int(results.pose_landmarks.landmark[15].x * image.shape[1]), int(results.pose_landmarks.landmark[15].y * image.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(0, 0, 255), thickness=2)
                
    #                 targeted_pose_landmarks = mp_holistic.PoseLandmark
    #                 for connection in pose_connections:
    #                     start_idx, end_idx = connection
    #                     start_landmark = results.pose_landmarks.landmark[start_idx]
    #                     end_landmark = results.pose_landmarks.landmark[end_idx]
    #                     if start_landmark and end_landmark:
    #                         # 연결선 그리기
    #                         mp_drawing.draw_landmarks(
    #                             image=output_image,
    #                             landmark_list=results.pose_landmarks,
    #                             connections=[(start_idx, end_idx)],
    #                             landmark_drawing_spec=None,
    #                             connection_drawing_spec=mp_drawing.DrawingSpec(color=(0, 255, 0), thickness=2, circle_radius=2))

    #                 # 개별 랜드마크 그리기
    #                 for landmark_idx in pose_landmark_indices:
    #                     landmark = results.pose_landmarks.landmark[landmark_idx]
    #                     if landmark:
    #                         x = int(landmark.x * image.shape[1])
    #                         y = int(landmark.y * image.shape[0])
    #                         cv2.circle(output_image, (x, y), 4, (255, 0, 0), -1)

    #             cv2.imshow('Raw Webcam Feed', output_image)

    #             if cv2.waitKey(10) & 0xFF == ord('q'):
    #                 break

    #     cap.release()
    #     cv2.destroyAllWindows()


    def _handle_client(self, client_socket):
        step = 0
        flag=True
        while True:
            try:
                BUFF_SIZE = 1024
                LIMIT_TIME = 10
                send_value = self.SMART.contorol_motor([0x31],[200])
                print(bytes(send_value))
                client_socket.sendall(bytes(send_value))

                time.sleep(0.001)

            except socket.timeout as err:
                print('self.self.client_socket Timeout Error')
                
                # 추가적인 예외처리 로직 구성...
                self._close_client(client_socket)
                break
            except socket.error as err:
                self._close_client(client_socket)
                break

    # def clientRead(self, client_socket):
        # BUFF_SIZE= 64
        # delay_data_queue = deque(maxlen=1000)

        # # 최대값을 추적할 우선순위 큐
        # max_heap = []

        # print("soket id : ", client_socket)
        # while(1):
        #     try:
        #         client_data = client_socket.recv(1024)
        #         decodedData = float(client_data.decode())
        #         delay = (time.time() - decodedData)/2

        #         delay_data_queue.append(delay)  # 데이터 큐에 추가

        #         # 최소값, 최대값 추적을 위해 데이터를 우선순위 큐에 추가
        #         heapq.heappush(max_heap, delay)
        #         while len(max_heap) > 5:
        #             heapq.heappop(max_heap)

        #         if len(delay_data_queue) % 100==0:
        #             print(len(delay_data_queue))

        #         if len(delay_data_queue) == 1000:
        #             # 최근 1000개의 데이터를 모두 수집한 경우
        #             average_delay = sum(delay_data_queue) / 1000
        #             max_delay = max(delay_data_queue)
        #             min_delay = min(delay_data_queue)
        #             print('='*40)
        #             print("delay 데이터 1000개의 평균 : ", average_delay)
        #             print("delay 데이터 1000개중 최대 : ", max_delay)
        #             print("delay 데이터 1000개중 최소 : ", min_delay)
                    
        #             print("최대값 5개:", [-x for x in max_heap])
        #     except Exception as e:
        #         print("err code : ", e)
        #         pass

    def _close_client(self, client_socket):
        client_socket.close()

if __name__ == "__main__":
    server = SocketServer()