BackGroundStyle = """
                background : #1f316f;
                border : None;
            """

ButtonStyle = """ 
        QPushButton{
        background : #707070;
            border : solid 1px;
            color : White;
        }
        QPushButton:releasd{
            background : #707070;
            border : solid 1px;
            color : White;
        }        
        QPushButton:pressed{
                background : White;
                border : solid 1px;
                color : #707070;
        }                
        """

BackButtonStyle = """ 
        QPushButton{
        background : #FF3131;
            border : solid 1px;
        }
        """

LabelStyle = """
                background : #6b6b6b;
                border : soild 1px;
            """
IMGStyle ="""
                background : transparent;
                border : None;
            """

itemsStyle = """
    background : White;
    border : solid 1px;
    color : black;
"""



ConnectionStateLStyle = """ 
        background : green;
        border : None;   
    """
DisConnectionStateLStyle = """ 
        background : red;
        border : None;   
    """